package com.ecommerce.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ecommerce.entity.Cart;
import com.ecommerce.entity.Product;
import com.ecommerce.entity.Registration;
import com.ecommerce.repository.CartRepository;
import com.ecommerce.repository.ProductRepository;
import com.ecommerce.repository.RegistrationRepository;

@Service
@Transactional
public class CartService {

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private RegistrationRepository registrationRepository;

    public Cart addToCart(Long userId, Long productId, int quantity) {
        Registration registration = registrationRepository.findById(userId)
            .orElseThrow(() -> new RuntimeException("User not found"));
        Product product = productRepository.findById(productId)
            .orElseThrow(() -> new RuntimeException("Product not found"));

        Cart cart = new Cart();
        cart.setRegistration(registration);
        cart.setProduct(product);
        cart.setQuantity(quantity);

        return cartRepository.save(cart);
    }
    
    public List<Cart> getUserCart(Long userId) {
        return cartRepository.findByRegistration_Rid(userId);
    }

    // Additional methods to manage the cart
    public void clearCart(Long userId) {
        cartRepository.deleteByRegistration_Rid(userId);
    }

}
