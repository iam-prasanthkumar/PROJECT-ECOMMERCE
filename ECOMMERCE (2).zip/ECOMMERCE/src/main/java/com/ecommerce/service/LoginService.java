package com.ecommerce.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.entity.Registration;
import com.ecommerce.repository.RegistrationRepository;

@Service
public class LoginService {

    @Autowired
    private RegistrationRepository registrationRepository;
///
    public Registration loginUser(String email, String password) {
        Registration registration = registrationRepository.findByEmailId(email);
        if (registration == null || !registration.getPassword().equals(password)) {
            throw new RuntimeException("Invalid email or password");
        }
        return registration;
    }
    
    
}
