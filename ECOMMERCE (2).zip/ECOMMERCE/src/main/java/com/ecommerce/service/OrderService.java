package com.ecommerce.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ecommerce.entity.Cart;
import com.ecommerce.entity.Order;
import com.ecommerce.entity.OrderItem;
import com.ecommerce.entity.Product;
import com.ecommerce.repository.CartRepository;
import com.ecommerce.repository.OrderItemRepository;
import com.ecommerce.repository.OrderRepository;
import com.ecommerce.repository.ProductRepository;

import java.time.LocalDateTime;
import java.util.List;

import javax.management.RuntimeErrorException;

@Service
@Transactional
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private OrderItemRepository orderItemRepository;
    
    @Autowired
    ProductRepository productRepository;

    public Order placeOrder(Long userId) {
        List<Cart> cartItems = cartRepository.findByRegistration_Rid(userId);

        if (cartItems.isEmpty()) {
            throw new RuntimeException("Cart is empty");
        }

        Order order = new Order();
        order.setRegistration(cartItems.get(0).getRegistration());
        order.setOrderDate(LocalDateTime.now());
        order.setStatus("Pending");

       
        Order savedOrder = orderRepository.save(order);

        for (Cart cart : cartItems) {
        	
            OrderItem orderItem = new OrderItem();
            orderItem.setOrder(savedOrder);
            orderItem.setProduct(cart.getProduct());
            orderItem.setQuantity(cart.getQuantity());
            orderItem.setPrice(cart.getProduct().getPprice());
            orderItemRepository.save(orderItem);
            
            
            //Decrease product quantity.....
            
            Product product=cart.getProduct();
            int newQuantity =product.getPquantity()-cart.getQuantity();
            if(newQuantity < 0) {
            	throw new RuntimeException("Insuffcient product quantity for product:"+product.getPname());
            }
            product.setPquantity(newQuantity);
            productRepository.save(product);
        }

        cartRepository.deleteAll(cartItems);
        
        

       
     // After saving the order items, update the order status to "Success"
        savedOrder.setStatus("Success");
        orderRepository.save(savedOrder);

        return savedOrder;
    }
    
    
}
