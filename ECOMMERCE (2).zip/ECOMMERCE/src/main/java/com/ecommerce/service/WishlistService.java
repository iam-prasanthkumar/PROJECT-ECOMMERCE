package com.ecommerce.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.ecommerce.entity.Wishlist;
import com.ecommerce.dto.WishlistResponse;
import com.ecommerce.entity.Product;
import com.ecommerce.entity.Registration;
import com.ecommerce.repository.WishlistRepository;
import com.ecommerce.repository.ProductRepository;
import com.ecommerce.repository.RegistrationRepository;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class WishlistService {

    @Autowired
    private WishlistRepository wishlistRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private RegistrationRepository registrationRepository;

    public Wishlist addToWishlist(Long userId, Long productId) {
        Registration registration = registrationRepository.findById(userId)
            .orElseThrow(() -> new RuntimeException("User not found"));
        Product product = productRepository.findById(productId)
            .orElseThrow(() -> new RuntimeException("Product not found"));

        Wishlist wishlist = new Wishlist();
        wishlist.setRegistration(registration);
        wishlist.setProduct(product);

        return wishlistRepository.save(wishlist);
    }

    public List<WishlistResponse> getUserWishlist(Long userId) {
    	Registration registration = registrationRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));
    	List<Wishlist> wishlistItems = wishlistRepository.findByRegistration_Rid(userId);
    	
    	return wishlistItems.stream().map(item -> new WishlistResponse(
                registration.getEmailId(),
                item.getProduct().getPid(),
                item.getProduct().getPname(),
                item.getProduct().getPprice()
        )).collect(Collectors.toList());
    }

    public void removeFromWishlist(Long userId, Long productId) {
        wishlistRepository.deleteByRegistration_RidAndProduct_Pid(userId, productId);
    }
}
