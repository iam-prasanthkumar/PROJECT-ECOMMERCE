package com.ecommerce.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ecommerce.dto.UserDTO;
import com.ecommerce.entity.Registration;
import com.ecommerce.repository.RegistrationRepository;

@Service
public class AdminService {

    @Autowired
    private RegistrationRepository adminRepository;

    @Transactional
    public Registration registerRegistration(Registration admin) {
        if (adminRepository.findByEmailId(admin.getEmailId()) != null) {
            throw new RuntimeException("Registration already exists with this email");
        }
        admin.setRegistrationFlag(false);
        return adminRepository.save(admin);
    }

    @Transactional
    public Registration updateRegistration(Long adminId, Registration updatedRegistration) {
        Registration existingRegistration = adminRepository.findById(adminId)
                .orElseThrow(() -> new RuntimeException("Registration not found"));
        existingRegistration.setEmailId(updatedRegistration.getEmailId());
        existingRegistration.setPassword(updatedRegistration.getPassword());
        existingRegistration.setPhoneNumber(updatedRegistration.getPhoneNumber());
        return adminRepository.save(existingRegistration);
    }

    public UserDTO getRegistrationByEmail(String email) {
        Registration admin = adminRepository.findByEmailId(email);
        
        
        if (admin == null) {
            throw new RuntimeException("Registration not found");
        }
        
        UserDTO userDTO=new UserDTO();
        userDTO.setEmailId(admin.getEmailId());
        userDTO.setPhoneNumber(admin.getPhoneNumber());
        userDTO.setAddress(admin.getAddress());
        return userDTO;
    }

    @Transactional
    public void deleteRegistrationById(Long adminId) {
        Registration existingRegistration = adminRepository.findById(adminId)
                .orElseThrow(() -> new RuntimeException("Registration not found"));
        adminRepository.delete(existingRegistration);
    }
}
