package com.ecommerce.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ecommerce.entity.Registration;
import com.ecommerce.repository.RegistrationRepository;

@Service
public class RegistrationService {

    @Autowired
    private RegistrationRepository registrationRepository;

    @Transactional
    public Registration registerUser(Registration registration) {
        if (registrationRepository.findByEmailId(registration.getEmailId()) != null) {
            throw new RuntimeException("User already exists with this email");
        }
        registration.setRegistrationFlag(true); // Set flag as true to indicate successful registration
        return registrationRepository.save(registration);
    }

    @Transactional
    public Registration updateUser(Long userId, Registration updatedRegistration) {
        Registration existingRegistration = registrationRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));
        existingRegistration.setEmailId(updatedRegistration.getEmailId());
        existingRegistration.setPassword(updatedRegistration.getPassword());
        existingRegistration.setAddress(updatedRegistration.getAddress());
        existingRegistration.setPhoneNumber(updatedRegistration.getPhoneNumber());
        return registrationRepository.save(existingRegistration);
    }

    public Registration getUserById(Long userId) {
        return registrationRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));
    }

    public Registration getUserByEmail(String email) {
        Registration registration = registrationRepository.findByEmailId(email);
        if (registration == null) {
            throw new RuntimeException("User not found");
        }
        return registration;
    }

    @Transactional
    public void deleteUserByEmail(String email) {
        Registration registration = registrationRepository.findByEmailId(email);
        if (registration != null) {
            registrationRepository.delete(registration);
        } else {
            throw new RuntimeException("User not found");
        }
    }
}
