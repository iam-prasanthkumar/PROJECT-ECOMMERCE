package com.ecommerce.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.ecommerce.entity.Registration;
import com.ecommerce.service.RegistrationService;

@RestController
@RequestMapping("/api")
public class RegistrationController {

    @Autowired
    private RegistrationService registrationService;

    @PostMapping("/register")
    public Registration registerUser(@RequestBody Registration registration) {
        return registrationService.registerUser(registration);
    }

    @PutMapping("/user/{userId}")
    public Registration updateUser(@PathVariable Long userId, @RequestBody Registration registration) {
        return registrationService.updateUser(userId, registration);
    }

    @GetMapping("/user/{userId}")
    public Registration getUserById(@PathVariable Long userId) {
        return registrationService.getUserById(userId);
    }

    @GetMapping("/user/email/{email}")
    public Registration getUserByEmail(@PathVariable String email) {
        return registrationService.getUserByEmail(email);
    }

    @DeleteMapping("/user/email/{email}")
    public String deleteUserByEmail(@PathVariable String email) {
        registrationService.deleteUserByEmail(email);
        return "User with email " + email + " deleted successfully";
    }
}
