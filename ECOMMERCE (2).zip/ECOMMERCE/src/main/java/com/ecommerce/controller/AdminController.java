package com.ecommerce.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.ecommerce.dto.UserDTO;
import com.ecommerce.entity.Registration;
import com.ecommerce.service.AdminService;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

    @Autowired
    private AdminService adminService;

    @PostMapping("/register")
    public Registration registerAdmin(@RequestBody Registration admin) {
        return adminService.registerRegistration(admin);
    }

    @PutMapping("/update/{adminId}")
    public Registration updateAdmin(@PathVariable Long adminId, @RequestBody Registration admin) {
        return adminService.updateRegistration(adminId, admin);
    }

    @GetMapping("/email/{email}")
    public UserDTO getAdminByEmail(@PathVariable String email) {
        return adminService.getRegistrationByEmail(email);
    }

    @DeleteMapping("/delete/{adminId}")
    public String deleteAdminById(@PathVariable Long adminId) {
        adminService.deleteRegistrationById(adminId);
        return "Admin with ID " + adminId + " deleted successfully";
    }
}
