package com.ecommerce.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.ecommerce.entity.Cart;
import com.ecommerce.service.CartService;

@RestController
@RequestMapping("/api")
public class CartController {

    @Autowired
    private CartService cartService;

    @PostMapping("/cart/{userId}/{productId}")
    public Cart addToCart(@PathVariable Long userId, @PathVariable Long productId, @RequestParam int quantity) {
        return cartService.addToCart(userId, productId, quantity);
    }
    
    @DeleteMapping("/{userId}/clear")
    public String clearCart(@PathVariable Long userId) {
        cartService.clearCart(userId);
        return "Cart cleared successfully for user with ID: " + userId;
    }
    
    
}
