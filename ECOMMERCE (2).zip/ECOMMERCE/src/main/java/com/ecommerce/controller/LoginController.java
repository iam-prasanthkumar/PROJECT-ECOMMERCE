package com.ecommerce.controller;
import com.ecommerce.dto.LoginRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


import com.ecommerce.entity.Registration;
import com.ecommerce.service.LoginService;


@RestController
@RequestMapping("/api")
public class LoginController {

    @Autowired
    private LoginService loginService;
    
    LoginRequest loginRquest=new LoginRequest();
    
    @PostMapping("/login")
    
    public Registration loginUser(@RequestBody LoginRequest loginRequest) {
    	
    	
        return loginService.loginUser(loginRequest.getEmail(), loginRequest.getPassword());
    }
}



    // Getters and Setters

