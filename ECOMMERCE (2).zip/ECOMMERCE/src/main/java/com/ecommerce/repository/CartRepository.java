package com.ecommerce.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.ecommerce.entity.Cart;

import java.util.List;

public interface CartRepository extends JpaRepository<Cart, Long> {
    List<Cart> findByRegistration_Rid(Long rid);
    void deleteByRegistration_Rid(Long userId);
}

