package com.ecommerce.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.ecommerce.entity.Wishlist;

import java.util.List;

public interface WishlistRepository extends JpaRepository<Wishlist, Long> {
    List<Wishlist> findByRegistration_Rid(Long rid);
    void deleteByRegistration_RidAndProduct_Pid(Long userId, Long productId);
}
