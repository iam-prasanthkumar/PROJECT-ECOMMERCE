package com.ecommerce.dto;

public class WishlistResponse {

    private String username;
    private Long productId;
    private String productName;
    private Double productPrice;

    // Constructors, Getters and Setters
    public WishlistResponse(String username, Long productId, String productName, Double productPrice) {
        this.username = username;
        this.productId = productId;
        this.productName = productName;
        this.productPrice = productPrice;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public Double getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(Double productPrice) {
        this.productPrice = productPrice;
    }
}
