package com.ecommerce.dto;

public enum OtpStatus {

    DELIVERED,FAILED
}